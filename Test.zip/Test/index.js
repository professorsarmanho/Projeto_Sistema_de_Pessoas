const express = require("express");
const app = express();
const handlebars = require("express-handlebars");
const Handlebars = require('handlebars')

const bodyParser = require("body-parser");
const Pessoas = require("./models/Pessoas")
const Sequelize = require('sequelize');
const {allowInsecurePrototypeAccess} = require('@handlebars/allow-prototype-access')

// Config
// Template Engine
const { engine } = require ('express-handlebars');
app.engine('handlebars', engine());

app.set('view engine', 'handlebars');
app.set("views", "./views");
handlebars.ExpressHandlebars.prototype.layoutsDir = './views/layouts';

// Body Parser
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

// Rotas
// Home
app.get('/',function(req,res){
  Pessoas.findAll({order: [['id', 'desc']]}).then(function(pessoas){
    res.render('home',{pessoas: pessoas})
  })  // Retorna todos os registros da tabela de Pessoas
})

app.get('/cad',function(req,res) {
  res.render('formulario_de_pessoas');
})

app.pessoas('/add',function(req,res){
  // Criar um registro na tabela pessoas
  Pessoas.create({
    nome: req.body.nome,
    cpf: req.body.cpf,
    endereco: req.body.endereco,
    telefones: req.body.telefones,
    apartamento: req.body.apartamento,
    bloco: req.body.bloco
  }).then(function(){
    res.redirect('/')  // retorna para a rota principal
  }).catch(function(erro){
    res.send("Houve um Erro:" + erro)
  })
})
app.get('/deletar/:id',function(req,res){
  Pessoas.destroy({where: {'id': req.params.id}}).then(function(){
     res.send("Pessoa deletada com sucesso!")
  }).catch(function(erro){
    res.send("Esta pessoa não existe!")
  })
})

app.listen(8081, function() {
    console.log("servidor rodando na porta 8081");
  });
