// O arquivo db.js está na mesma pasta do arquivo Post.js
//const db = require("./db.js")

const Sequelize = require('sequelize');
// conexão com o banco de dados
const sequelize = new Sequelize('dbpessoas','root','',{
  host: "localhost",
  dialect: 'mysql'
})

// guardar a estrutura da tabela de postagens
const Pessoas = sequelize.define('pessoas', {
  nome: {
    type: Sequelize.STRING
  },
  cpf: {
    type: Sequelize.STRING
  },
  endereco: {
    type: Sequelize.STRING
  },
  telefones: {
    type: Sequelize.STRING
  },
  apartamento: {
    type: Sequelize.STRING
  },
  bloco: {
    type: Sequelize.STRING
}})

module.exports = Pessoas; // queremos utilizar o Post em outros arquivos do projeto

// cria/recria a tabela
//Pessoas.sync({force: true})
